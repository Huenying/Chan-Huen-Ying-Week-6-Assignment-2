import math
import re
from typing import Dict, Any

class Tool:
    def __init__(self, name: str, description: str, fn):
        self.name = name
        self.description = description
        self.fn = fn

    def execute(self, **kwargs) -> Dict[str, Any]:
        try:
            return self.fn(**kwargs)
        except Exception as e:
            return {"error": str(e)}

def sentiment_scorer(text: str) -> Dict[str, Any]:
    """
    Heuristic-based sentiment scoring analyzer tailored for business and news text.
    
    Aim: 
        It is designed for quick analysis on financial reports, press releases or news articles where a fast and interpretable positive/negative/neutral signal is needed.
    
    Args:
        text (str): Input text to analyze.
    
    Returns:
        Dict[str, Any]: {'sentiment': 'positive'|'negative'|'neutral', 'score': float (0-1)}

    Error Handling:
        - If the input text is empty or not a string, raises a ValueError indicating invalid input
        - Tool execution errors are caught and returned as error messages in the output dictionary
    """
    # Error handling for empty or non-string input
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Input text must be a non-empty string.")
    
    # Define keyword lists with scores
    positive_words = {
        "good": 1.0, "great": 1.5, "excellent": 2.0, 
        "profit": 2.0, "growth": 1.5, "success": 1.5,
        "beat": 1.0, "outperform": 1.5, "upgrade": 1.0,
        "positive": 1.0, "benefit": 1.0
    }
    
    negative_words = {
        "bad": 1.0, "poor": 1.0, "worst": 2.0,
        "loss": 2.0, "decline": 1.5, "downgrade": 1.0,
        "miss": 1.0, "underperform": 1.5, "negative": 1.0,
        "risk": 1.0, "problem": 1.0, "fail": 1.5
    }
    
    negation_words = {"not", "no", "never", "neither", "nor", "don't", "doesn't"}
    
    # Preprocess text: lowercase and split into sentences
    text_lower = text.lower()
    sentences = re.split(r'[.!?]+', text_lower)
    total_score = 0.0
    word_count = 0

    # Analyze each sentence for sentiment
    for sentence in sentences:
        if not sentence.strip():
            continue

        words = sentence.split()
        negation_active = False

        for i, word in enumerate(words):
            word_count += 1

            if word in negation_words:
                negation_active = True
                continue

            if word in {'.', '!', '?', ',', ';', ':'} or (i > 0 and i % 6 == 0):
                negation_active = False

            score = 0.0

            if word in positive_words:
                score = positive_words[word]
                if negation_active:
                    score = -score * 0.8   
            elif word in negative_words:
                score = -negative_words[word]
                if negation_active:
                    score = -score * 0.8   

            total_score += score

    max_magnitude = word_count * 1.2   

    # Normalize score to 0-1 range
    score = 1.0 / (1.0 + math.exp(-total_score * 2.2 / max(1.0, max_magnitude / 8)))

    # Determine sentiment category
    if score > 0.62:
        sentiment = "positive"
    elif score < 0.38:
        sentiment = "negative"
    else:
        sentiment = "neutral"

    # Return the sentiment and score in a structured format JSON-like dictionary
    return {"sentiment": sentiment, "score": score}


