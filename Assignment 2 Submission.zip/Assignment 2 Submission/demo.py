
import os
import json
from typing import Dict, Any

from dotenv import load_dotenv
from openai import OpenAI

from tool import Tool, sentiment_scorer

load_dotenv()
API_KEY = os.getenv("DEEPSEEK_API_KEY")
if not API_KEY:
    raise EnvironmentError("DEEPSEEK_API_KEY not set in environment. Please create a .env file or set the variable.")


TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "sentiment_scorer",
        "description": "Heuristic-based sentiment scoring analyzer for business and news text.",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to analyze."}
            },
            "required": ["text"]
        }
    }
}

client = OpenAI(
    api_key=API_KEY,
    base_url="https://api.deepseek.com"
)

tool = Tool(
    name="sentiment_scorer",
    description="Heuristic-based sentiment analyzer for business/news text.",
    fn=sentiment_scorer
)

class SimpleAgent:
    def __init__(self, tool: Tool):
        self.tool = tool
        self.client = client
        self.model = "deepseek-chat"

    def analyze_text(self, text: str) -> Dict[str, Any]:

        """
        Analyze the sentiment of the provided text using Agent with sentiment_scorer tool
        
        Args:
            text (str): The text to analyze for sentiment. Must be a non-empty string.
            
        Returns:
            Dict[str, Any]: A dictionary containing either:
                - Success case: The sentiment analysis results from the tool
                - Direct response: The model's direct response when no tool is used (p.s: User content is specifically asking for sentiment analysis, so this is less likely)
                - Error case: An error message with details
        Error Handling:
            - If the input text is empty or not a string, returns an error message indicating invalid input.
            - If the API call fails or the tool execution raises an exception, returns an error message with details.
            - If the agent decides to call the tool, it processes the tool call and returns the result or any errors from the tool execution.
        """


        # Error handling for empty input or non-string input
        if not isinstance(text, str) or not text.strip():
            print("Empty Input or Invalid input type. Please provide a non-empty string.")
            return {"error": "Input text must be a non-empty string."}

        messages = [
            {
                "role": "system",
                "content": "You are a helpful business/news analyst. Use the sentiment_scorer tool when the user asks to analyze sentiment."
            },
            {
                "role": "user",
                "content": f"Analyze the sentiment of this text: '{text}'"
            }
        ]

        try:
            # Call the API with tool integration
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=[TOOL_SCHEMA],
                tool_choice="auto",         
                temperature=0.3,
                max_tokens=500
            )
            # Process the response to check for tool calls
            message = response.choices[0].message

            # Check if the agent decided to call the tool
            if message.tool_calls:
                tool_call = message.tool_calls[0]
                function_name = tool_call.function.name
                arguments = json.loads(tool_call.function.arguments)

                print(f"Agent decided to call tool: {function_name}")
                print(f"With arguments: {arguments}")

                result = self.tool.execute(**arguments)

                if "error" in result:
                    print(f"Tool Error: {result['error']}")
                else:
                    print(f"Tool Success: {result}")
                return result

            else:
                print("Agent replied directly (no tool used):")
                print(message.content)
                return {"direct_response": message.content}

        except Exception as e:
            print(f"API / Execution Error: {e}")
            return {"error": str(e)}



if __name__ == "__main__":
    agent = SimpleAgent(tool)

    print("\n--- Case 1: Successful Execution (Positive)---")
    agent.analyze_text("Our company delivered excellent quarterly results with strong profit growth across all divisions. The successful product launch exceeded expectations, and we are pleased to announce an upgrade to our guidance. Customer feedback remains overwhelmingly positive, reflecting the great work of our dedicated team and the strong momentum in our business.")

    print("\n--- Case 2: Successful Execution (Negative) ---")
    agent.analyze_text("The company reported poor quarterly results with significant losses and declining revenues across key divisions. The failed product launch missed expectations, forcing us to announce a downgrade to our guidance. Customer feedback has been overwhelmingly negative, reflecting serious problems with our operations and increased risk factors ahead.")

    print("\n--- Case 3: Empty Input ---")
    agent.analyze_text("")

    print("\n--- Case 4: Invalid Input (Non-string) ---")
    agent.analyze_text(123)
